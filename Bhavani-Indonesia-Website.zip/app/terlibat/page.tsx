import {Footer} from "@/components/Footer";
import {Header} from "@/components/Header";
import {fallbackSettings} from "@/lib/fallback";
import type {Settings} from "@/lib/types";
import {sanityFetch, settingsQuery} from "@/sanity/lib/queries";

export const metadata = {title: "Terlibat Bersama"};
export default async function ContactPage() {
  const settings = await sanityFetch<Settings>(settingsQuery, fallbackSettings);
  return <><Header/><main><section className="page-hero"><div className="shell"><span className="eyebrow">Terlibat bersama</span><h1>Kolaborasi dimulai dari percakapan yang jujur.</h1><p>Terlibat sebagai mitra komunitas, narasumber, relawan, media partner, atau sponsor.</p></div></section><section className="section"><div className="shell contact"><div><h2>Ada banyak cara untuk bertumbuh bersama.</h2><p>Email kami atau kirim pesan langsung melalui Instagram.</p></div><div className="contact-links"><a href={`mailto:${settings.email}`}>{settings.email}</a><a href={`https://instagram.com/${settings.instagram}`}>@{settings.instagram}</a></div></div></section></main><Footer settings={settings}/></>;
}
